from django.apps import AppConfig


class AppSecondConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_second'
